//
//  KVPackage.swift
//  Ares005
//
//  Created by Kenn Villegas on 10/13/15.
//  Copyright © 2015 K3nV. All rights reserved.
//

import Foundation
import CoreData


class KVPackage: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
