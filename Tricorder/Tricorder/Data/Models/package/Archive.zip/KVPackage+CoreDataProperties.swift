//
//  KVPackage+CoreDataProperties.swift
//  Ares005
//
//  Created by Kenn Villegas on 10/13/15.
//  Copyright © 2015 K3nV. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension KVPackage {

    @NSManaged var senderAddress: String?
    @NSManaged var recieverAddress: String?
    @NSManaged var senderState: String?
    @NSManaged var recieverState: String?
    @NSManaged var cost: NSNumber?
    @NSManaged var dueDate: NSDate?
    @NSManaged var price: NSNumber?
    @NSManaged var rating: NSNumber?
    @NSManaged var skuID: String?
    @NSManaged var startDate: NSDate?
    @NSManaged var senderZip: String?
    @NSManaged var recieverZip: String?
    @NSManaged var recieverName: String?
    @NSManaged var senderName: String?
    @NSManaged var currentVehicle: NSManagedObject?
    @NSManaged var billableItem: KVPerson?

}
